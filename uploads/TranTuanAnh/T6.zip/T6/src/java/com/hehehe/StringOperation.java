package com.hehehe;

public class StringOperation {

    public static String up(String s) {
        return s.toUpperCase();
    }

    public static String low(String s) {
        return s.toLowerCase();
    }
}
