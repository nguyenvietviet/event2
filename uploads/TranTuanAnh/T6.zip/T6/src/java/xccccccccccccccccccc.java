
public class xccccccccccccccccccc {

    public static void main(String[] args) {
        String s = "ha noi mua thu, mua thu ha noi";
        String[] arr = s.split(",");
        for (String sss : arr) {
            System.out.println(sss);
        }
    }
}
