package repo;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import model.SinhVien;

public class SinhVienRepository {

    private EntityManager em;

    public SinhVienRepository() {
        //        Persistence.createEntityManagerFactory("ten nay duoc cau hinh trong persistent.xml, ti nua check")
        em = Persistence.createEntityManagerFactory("T4_2PU").createEntityManager();
    }

    public List<SinhVien> findAll() {
//        String hql = "select a from model.SinhVien a";
        String hql = String.format("select a from %s a", SinhVien.class.getName());

        List<SinhVien> list = em.createQuery(hql).getResultList();

        return list;
    }

    public List<SinhVien> findByName(String tenSv) {
        String hql = String.format("select a from %s a where a.name like :tenSinhVien", SinhVien.class.getName());

        List<SinhVien> list = em.createQuery(hql)
                .setParameter("tenSinhVien", "%" + tenSv + "%")
                .getResultList();

        return list;
    }
    
    public SinhVien findById(String maSv){
        SinhVien sv = em.find(SinhVien.class, maSv);
        return sv;
    }
    public boolean xoa(String maSv){
        //b1: lay ve --> b2: xoa
        //cac chuc nang: addnew/update/delete phai nam trong 1 transaction
        em.getTransaction().begin();
        SinhVien sv = em.find(SinhVien.class, maSv);
        em.remove(sv);
        em.getTransaction().commit();
        
        return true;
    }
    public boolean addNew(SinhVien sv){
        //cac chuc nang: addnew/update/delete phai nam trong 1 transaction
        em.getTransaction().begin();
        em.persist(sv);
        em.getTransaction().commit();
        
        return true;
    }
    public boolean update(SinhVien sv){
        //cac chuc nang: addnew/update/delete phai nam trong 1 transaction
        em.getTransaction().begin();
        em.merge(sv);
        em.getTransaction().commit();
        
        return true;
    }
}
