package sv;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.SinhVien;
import repo.SinhVienRepository;

@WebServlet(name = "ChuanBiData4Update", urlPatterns = {"/ChuanBiData4Update"})
public class ChuanBiData4Update extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String rollNo = request.getParameter("roll");
        SinhVien stu = new SinhVienRepository().findById(rollNo);
        if (stu == null) {
            request.setAttribute("msg", "Huu khong tim thay stu voi roll " + rollNo);
//            request.getRequestDispatcher("list.jsp").forward(request, response);
            //de ve duoc list.jsp thi phai thong qua ViewAll servlet, vi ViewAll servlet lay all data cho
            request.getRequestDispatcher("ViewAll").forward(request, response);
        } else {
            request.setAttribute("stu", stu);
            request.getRequestDispatcher("edit.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
