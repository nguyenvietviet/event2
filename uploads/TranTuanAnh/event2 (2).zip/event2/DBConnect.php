<?php
function open() {  
	$host = "localhost";
    $user = "root";
    $password = "";
    $database = "sukien";
	$mysqli_connect = mysqli_connect($host, $user, $password, $database)or die("không thể kết nối tới database");

    return $mysqli_connect;
}

function close($mysqli_connect) {
    mysqli_close($mysqli_connect);
}

?>