<?php
   if(isset($_GET['edit_id'])){
   $conn=open();
    $sql = "SELECT * FROM sukien WHERE MaSuKien =" .$_GET['edit_id'];
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result);
    //get noi to chuc
    $dd=array();
    $i=0;
    $sql2 = "SELECT * FROM noitochuc";
     $result2 = mysqli_query($conn, $sql2);
    while ($row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC)) {
               $dd[$i]=$row2;
         $i++;
           }
           //get ban to chuc
           $btc=array();
           $i=0;
 $sql2 = "SELECT * FROM phongban";
     $result2 = mysqli_query($conn, $sql2);
    while ($row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC)) {
               $btc[$i]=$row2;
         $i++;
           }

           //get nguoi chi tri
    $nct=array();
    $i=0;
    $sql1 = "SELECT * FROM nguoichutri";
     $result1 = mysqli_query($conn, $sql1);
    while ($row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC)) {
               $nct[$i]=$row1;
         $i++;
           }
   //get thanh phan tham du
           $i=0;
           $tptd=array();
           $sql3 = "SELECT * FROM phongban";
      $result3 = mysqli_query($conn, $sql3);
        while ($row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC)) {
               $tptd[$i]=$row3;
        $i++;
           }
           //get ca nhan
            $i=0;
           $tpcn=array();
           $sql4 = "SELECT * FROM taikhoan";
      $result4 = mysqli_query($conn, $sql4);
        while ($row4 = mysqli_fetch_array($result4, MYSQLI_ASSOC)) {
          $tpcn[$i]=$row4;
          $i++;
        }
   
   //get to chuc
       $i=0;
       $tc="";
           $sql5 = "SELECT * FROM thanhphan_phongban where MaSuKien=".$row['MaSuKien']."";
       $result5 = mysqli_query($conn, $sql5);
    while ($row5 = mysqli_fetch_array($result5, MYSQLI_ASSOC)) {
             
         $tc.="'".$row5["MaPhongBan"]."',";
         $i++;
           }
   
       //get ca nhan
       
       $i=0;
       $can="";
           $sql6 = "SELECT * FROM thanhphan_taikhoan where MaSuKien=".$row['MaSuKien']."";
       $result6 = mysqli_query($conn, $sql6);
    while ($row6 = mysqli_fetch_array($result6, MYSQLI_ASSOC)) {
             
         $can.="'".$row6["MaTaiKhoan"]."',";
         $i++;
           }
   }
   
   if(isset($_POST['getTC'])){
    $conn=open();
    $arr = explode(",",$_POST['getTC']);
    $arr2=$row['MaSuKien'];
   $update2="DELETE FROM thanhphan_phongban WHERE MaSuKien=".$arr2."";
   $up2 = mysqli_query($conn, $update2);
   foreach ($arr as $ar){
     $update3 = "INSERT INTO thanhphan_phongban (MaPhongBan,MaSuKien) VALUES ($ar,$arr2);";
    $up3 = mysqli_query($conn, $update3);
   }
   }
   
   
   if(isset($_POST['getCN'])){
    $conn=open();
    $arr = explode(",",$_POST['getCN']);
    $arr2=$row['MaSuKien'];
      $update2 = "DELETE FROM thanhphan_taikhoan WHERE MaSuKien=".$arr2."";
      $up2 = mysqli_query($conn, $update2);
   foreach ($arr as $ar){
     $update3 = "INSERT INTO thanhphan_taikhoan(MaTaiKhoan,MaSuKien) VALUES ($ar,$arr2);";
    $up3 = mysqli_query($conn, $update3);
   }
   }
   
   //Update Information
   if(isset($_POST['btn-update'])){
    $ngaytochuc = $_POST['ngaytochuc'];
    $thoigianbatdau = $_POST['thoigianbatdau'];
    $thoigianketthuc = $_POST['thoigianketthuc'];
    $diadiem = $_POST['select_dd'];
    $noidung = $_POST['noidung'];
    $nguoichutri = $_POST['select_nct'];
    $tpkhac=$_POST['thanhphankhac'];
    $bantochuc=$_POST['select_btc'];
    if($tpkhac==""){$tpkhac='null';}
    $update = "UPDATE sukien SET NgayToChuc='$ngaytochuc', ThoiGianBatDau='$thoigianbatdau',ThoiGianKetThuc='$thoigianketthuc',NoiDung='$noidung',DiaDiem=$diadiem,ThanhPhanThamDuKhac=$tpkhac,NguoiChuTri='$nguoichutri',ThanhPhanToChuc='$bantochuc' WHERE MaSuKien=". $_GET['edit_id'];
    $up = mysqli_query($conn, $update);
    if(!isset($sql)){
    die ("Error $sql" .mysqli_connect_error());
    }
    else
    {
    header("location: admin.php");
    }
   }
   ?>

  <script src="ckeditor/ckeditor.js"></script>
<!--Create Edit form -->
<form method="post">
   <div class="container-fluid">
      <div class="card show mb-4">
         <div class="card">
            <div class="card-header">
               <strong class="card-title">Edit Sự Kiện</strong>
            </div>
            <div class="card-body">
               <h4>Edit</h4>
               <div class="row">
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Ngày tổ chức:</label><input class="form-control" type="date" name="ngaytochuc" value="<?php echo $row['NgayToChuc']; ?>">
                  </div>
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Thời gian bắt đầu:</label><input class="form-control" type="time" name="thoigianbatdau"  value="<?php echo $row['ThoiGianBatDau']; ?>">
                  </div>
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Thời gian kết thúc:</label><input class="form-control" type="time" name="thoigianketthuc"  value="<?php echo $row['ThoiGianKetThuc']; ?>">
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Địa điểm: </label>
                     <select name="select_dd" class="form-control">
                        <?php
                           foreach($dd as $noitochuc){?>
                        <option value="<?=$noitochuc['ID']?>"<?php if($noitochuc['ID']==$row['DiaDiem'])echo "selected";?>><?= $noitochuc['DiaDiem'];?></option>
                        <?php  }?>
                     </select>
                  </div>
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Người chủ trì:</label>
                     <select name="select_nct" class="form-control">
                        <?php
                           foreach($nct as $ngct){?>
                        <option value="<?=$ngct['ID']?>"<?php if($ngct['ID']==$row['NguoiChuTri'])echo "selected";?>><?= $ngct['TenNguoiChuTri'];?></option>
                        <?php  }?>
                     </select>
                  </div>
                  <div class="col-md-3 mb-3">
                     <label>Thành phần tham gia khác:</label>
                     <input class="form-control" type="text" name="thanhphankhac" value="<?=$row['ThanhPhanThamDuKhac']?>"><br>
                     <input type="hidden" id="getTC" name="getTC" >
                     <input type="hidden" id="getCN" name="getCN" >
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-3 mb-3">
                     <label>Ban tổ chức:</label>
                      <select name="select_btc" class="form-control">
                        <?php
                           foreach($btc as $dsbtc){?>
                        <option value="<?=$dsbtc['MaPhongBan']?>"<?php if($dsbtc['MaPhongBan']==$row['ThanhPhanToChuc'])echo "selected";?>><?=$dsbtc['TenPhongBan']?></option>
                        <?php  }?>
                     </select>                    
            
                  </div>
                  <div class="col-md-3 mb-3">
                     <label>Cá nhân:</label>
                     <select  id="cn" class="selectpicker canhan form-control" multiple data-live-search="true">
                        <?php foreach($tpcn as $cn){?>
                        <option value="<?=$cn['ID']?>" select><?=$cn['TenTaiKhoan']?></option>
                        <?php  }?>
                     </select>
                  </div>
                  <div class="col-md-3 mb-3">
                     <label>Thành phần tham gia:</label>
                     <select  id ="tc" class="selectpicker tochuc form-control" multiple data-live-search="true">
                        <?php
                           foreach($tptd as $tp){?>
                        <option value="<?=$tp['MaPhongBan']?>"><?=$tp['TenPhongBan']?></option>
                        <?php  }?>
                     </select>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">  
                     <label>Nội dung:</label>
                     <textarea class="form-control ckeditor" name="noidung" rows="5" cols="50"> <?php echo $row['NoiDung']; ?></textarea>
                  </div>
               </div>
               <div class="row" style="margin-top: 10px; margin-left:0px;"> 
                  <button type="submit" class="btn btn-primary btn-sm m-1" name="btn-update" id="btn-update" onClick="update()"><i class="fa fa-dot-circle-o"></i>Update</button>
                  <a href="admin.php"><button type="button" class="btn btn-danger btn-sm m-1" value="button">Cancel</button></a>
               </div>
            </div>
         </div>
      </div>
   </div>
</form>
<!-- Alert for Updating -->

<script>
   $(document).ready(function () {
   $('.tochuc').selectpicker('val', [<?php echo $tc?>]);
   $('.canhan' ).selectpicker('val', [<?php echo $can?>]);
   });
   function tt(){
   
    var tc=$('#tc').val();
    var cn=$('#cn').val();
   document.getElementById('getTC').value=tc;
   document.getElementById('getCN').value=cn;
   
   }
   function update(){
    tt();
    var x;
    if(confirm("Updated data Sucessfully") == true){
    x= "update";
    }
   }
</script>