
<?php
$conn=open();
    
    //get noi to chuc
    $dd=array();
    $i=0;
    $sql2 = "SELECT * FROM noitochuc";
     $result2 = mysqli_query($conn, $sql2);
    while ($row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC)) {
               $dd[$i]=$row2;
         $i++;
           }
           //get ban to chuc
           $btc=array();
    $i=0;
    $sql2 = "SELECT * FROM phongban";
     $result2 = mysqli_query($conn, $sql2);
    while ($row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC)) {
               $btc[$i]=$row2;
         $i++;
           }
           //get nguoi chi tri
    $nct=array();
    $i=0;
    $sql1 = "SELECT * FROM nguoichutri";
     $result1 = mysqli_query($conn, $sql1);
    while ($row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC)) {
               $nct[$i]=$row1;
         $i++;
           }
   //get thanh phan tham du
           $i=0;
           $tptd=array();
           $sql3 = "SELECT * FROM phongban";
      $result3 = mysqli_query($conn, $sql3);
        while ($row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC)) {
               $tptd[$i]=$row3;
        $i++;
           }
           //get ca nhan
            $i=0;
           $tpcn=array();
           $sql4 = "SELECT * FROM taikhoan";
      $result4 = mysqli_query($conn, $sql4);
        while ($row4 = mysqli_fetch_array($result4, MYSQLI_ASSOC)) {
          $tpcn[$i]=$row4;
          $i++;
        }


    if (isset($_POST["btn-update"])) {

$ngaytochuc=$_POST['ngaytochuc'];
$thoigianbatdau=$_POST['thoigianbatdau'];
$thoigianketthuc=$_POST['thoigianketthuc'];
$diadiem=$_POST['select_dd'];
$thanhphankhac=$_POST['thanhphankhac'];
$canhan=$_POST['canhan'];
$thanhphanthamgia=$_POST['thanhphanthamgia'];
$nguoichutri=$_POST['select_nct'];
$noidung=$_POST['noidung'];
$bantochuc=$_POST['select_btc'];
//Our "then" date.
$then = "2019-09-16";
 
//Convert it into a timestamp.
$then = strtotime($ngaytochuc);
 
//Get the current timestamp.
$now = time();
 
//Calculate the difference.
$difference = $then - $now;
 
//Convert seconds into days.
$days = floor($difference / (60*60*24) );
$cuoituan=strtotime("sunday 1 week");
$days_next=floor(($then-$cuoituan) / (60*60*24) );
//validation ngay to chuc 
 if($days<0 || $days_next>0){
  echo "<p style='color:Tomato;'>Bạn phải chọn thời gian ngày mai hoặc tuần sau!!</p>";

 }
 if($ngaytochuc=="" || $thoigianbatdau=="" || $thoigianketthuc==""|| $diadiem==""|| $noidung==""|| $nguoichutri==""){
echo "<p style='color:Tomato;'> Bạn chưa chọn đầy đủ !!</p>";
 }

else if($thoigianbatdau>$thoigianketthuc){
echo "<p style='color:Tomato;'> Thời gian kết thúc phải sau thời gian bắt đầu!!</p>";
}

else {
  $date_now=date("Y-m-d");
$sql="INSERT INTO sukien (ThoiGianBatDau,ThoiGianKetThuc,ThanhPhanToChuc,DiaDiem,NoiDung,ThanhPhanThamDuKhac,NguoiChuTri,ID_NguoiTao,NgayTao,NgayToChuc,Duyet) VALUES ('$thoigianbatdau','$thoigianketthuc', $bantochuc,$diadiem,'$noidung', '$thanhphankhac', $nguoichutri,1,'$date_now','$ngaytochuc',0 )";
     $result = mysqli_query($conn, $sql);
         header("location: admin.php");


}

      }




   ?>
  <script src="ckeditor/ckeditor.js"></script>
<!--Create Edit form -->
<form method="post">
   <div class="container-fluid">
      <div class="card show mb-4">
         <div class="card">
            <div class="card-header">
               <strong class="card-title">Thêm Sự Kiện</strong>
            </div>
            <div class="card-body">
               <h4>Thêm</h4>
               <div class="row">
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Ngày tổ chức:</label><input class="form-control" type="date" name="ngaytochuc" value="<?php echo $row['NgayToChuc']; ?>">
                  </div>
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Thời gian bắt đầu:</label><input class="form-control" type="time" name="thoigianbatdau"  value="<?php echo $row['ThoiGianBatDau']; ?>">
                  </div>
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Thời gian kết thúc:</label><input class="form-control" type="time" name="thoigianketthuc"  value="<?php echo $row['ThoiGianKetThuc']; ?>">
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Địa điểm: </label>
                     <select name="select_dd" class="form-control">
                        <?php
                           foreach($dd as $noitochuc){?>
                        <option value="<?=$noitochuc['ID']?>"<?php if($noitochuc['ID']==$row['DiaDiem'])echo "selected";?>><?= $noitochuc['DiaDiem'];?></option>
                        <?php  }?>
                     </select>
                  </div>
                  <div class="col-md-3 mb-3">
                     <!-- <div class="form-group"> -->
                     <label>Người chủ trì:</label>
                     <select name="select_nct" class="form-control">
                        <?php
                           foreach($nct as $ngct){?>
                        <option value="<?=$ngct['ID']?>"<?php if($ngct['ID']==$row['NguoiChuTri'])echo "selected";?>><?= $ngct['TenNguoiChuTri'];?></option>
                        <?php  }?>
                     </select>
                  </div>
                  <div class="col-md-3 mb-3">
                     <label>Thành phần tham gia khác:</label>
                     <input class="form-control" type="text" name="thanhphankhac" value="<?=$row['ThanhPhanThamDuKhac']?>"><br>
                     <input type="hidden" id="getTC" name="getTC" >
                     <input type="hidden" id="getCN" name="getCN" >
                  </div>
               </div>
               <div class="row">
                   <div class="col-md-3 mb-3">
                     <label>Ban tổ chức:</label>
                      <select name="select_btc" class="form-control">
                        <option style="color:Tomato;">Chưa chọn</option>>
                        <?php
                           foreach($btc as $dsbtc){?>
                        <option value="<?=$dsbtc['MaPhongBan']?>"><?=$dsbtc['TenPhongBan']?></option>
                        <?php  }?>
                     </select>                    
            
                  </div>
                  <div class="col-md-3 mb-3">
                     <label>Cá nhân:</label>
                     <select  id="cn" class="selectpicker canhan form-control" multiple data-live-search="true" name="canhan">
                        <?php foreach($tpcn as $cn){?>
                        <option value="<?=$cn['ID']?>" select><?=$cn['TenTaiKhoan']?></option>
                        <?php  }?>
                     </select>
                  </div>
                  <div class="col-md-3 mb-3">
                     <label>Thành phần tham gia:</label>
                     <select  id ="tc" class="selectpicker tochuc form-control" multiple data-live-search="true" name="thanhphanthamgia">
                        <?php
                           foreach($tptd as $tp){?>
                        <option value="<?=$tp['MaPhongBan']?>"><?=$tp['TenPhongBan']?></option>
                        <?php  }?>
                     </select>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">  
                     <label>Nội dung:</label>
                     <textarea class="form-control ckeditor" name="noidung" rows="5" cols="50"> <?php echo $row['NoiDung']; ?></textarea>
                  </div>
               </div>
               <div class="row" style="margin-top: 10px; margin-left:0px;"> 
                  <button type="submit" class="btn btn-primary btn-sm m-1" name="btn-update" id="btn-update"><i class="fa fa-dot-circle-o"></i>Thêm</button>
                  <a href="admin.php"><button type="button" class="btn btn-danger btn-sm m-1" value="button">Cancel</button></a>
               </div>
            </div>
         </div>
      </div>
   </div>
</form>
<!-- Alert for Updating -->

